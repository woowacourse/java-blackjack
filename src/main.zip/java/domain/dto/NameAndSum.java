package domain.dto;

public record NameAndSum(
        String name,
        int sum
) {
    
}
